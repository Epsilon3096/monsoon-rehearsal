# Synthetic bench software exercise only

This archive retains the exact native artifacts from the internally generated calibration and withheld predictions. Observations were generated from the same solver plus declared 1 mm and 10 mm offsets; they are not independent hydraulic validation or physical measurements. No apparatus, participant or field outcome is represented.

The outer evidence-manifest.json verifies these portable archive entries. Original result JSON files retain their original absolute local paths and exact original bytes. Do not rewrite their content to pretend that the original local study ran elsewhere; reproduce a fresh exercise with the packaged application and compare numerical results instead.

The local SQLite ledger and credentials are not included. study.json is the verified exported study record. No dispatch, physical validation or full 24-run protocol completion is granted by any of these files.
